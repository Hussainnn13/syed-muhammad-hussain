import random
from flask import Flask, render_template, request, jsonify, session
from flask_session import Session
import nltk
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk import pos_tag
from nltk.corpus import wordnet

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)

nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')
nltk.download('wordnet')

distractors_dict = {
    "lahore": ["karachi", "islamabad", "multan"],
    "physics": ["chemistry", "biology", "math"],
    "dog": ["cat", "rabbit", "hamster"],
    "car": ["bike", "bus", "truck"],
    "university": ["college", "school", "academy"],
    "bus": ["car", "train", "bicycle"],
    "student": ["teacher", "doctor", "engineer"],
    "pakistan": ["india", "bangladesh", "nepal"]
}

default_distractors = [
    "lamp", "tree", "book", "fan", "bottle", "drum", "island", "river","vehicle","stick"
]

def generate_distractors(word):
    word_lower = word.lower()
    if word_lower in distractors_dict:
        return distractors_dict[word_lower]
    distractors = set()
    synsets = wordnet.synsets(word_lower, pos=wordnet.NOUN)
    if synsets:
        for syn in synsets:
            for lemma in syn.lemmas():
                name = lemma.name().replace('_', ' ')
                if name.lower() != word_lower:
                    distractors.add(name)
            for related_syn in syn.hyponyms() + syn.hypernyms():
                for lemma in related_syn.lemmas():
                    name = lemma.name().replace('_', ' ')
                    if name.lower() != word_lower:
                        distractors.add(name)
    if len(distractors) >= 3:
        return random.sample(list(distractors), 3)
    return random.sample(default_distractors, 3)

def generate_questions(text):
    questions = []
    sentences = sent_tokenize(text)
    for sentence in sentences:
        words = word_tokenize(sentence)
        tagged = pos_tag(words)
        for i, (word, tag) in enumerate(tagged):
            if tag in ["NN", "NNS", "NNP", "NNPS"]:
                correct_answer = word
                distractors = generate_distractors(correct_answer)
                options = distractors + [correct_answer]
                random.shuffle(options)
                blanked_sentence = sentence.replace(correct_answer, "____", 1)
                questions.append({
                    'question': blanked_sentence,
                    'options': options,
                    'answer': correct_answer
                })
                break
    return questions

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_text():
    text = request.form['text']
    questions = generate_questions(text)
    session['quiz_data'] = questions
    session['current_question'] = 0
    session['answers'] = []
    return jsonify({'status': 'success'})

@app.route('/next_question', methods=['POST'])
def next_question():
    index = session.get('current_question', 0)
    quiz = session.get('quiz_data', [])
    if index < len(quiz):
        session['current_question'] = index + 1
        return jsonify({
            'question': quiz[index]['question'],
            'options': quiz[index]['options']
        })
    else:
        return jsonify({'status': 'finished'})

@app.route('/submit_answer', methods=['POST'])
def submit_answer():
    index = session.get('current_question', 1) - 1
    answer = request.form['answer']
    quiz = session['quiz_data'][index]
    is_correct = answer == quiz['answer']
    session['answers'].append({
        'question': quiz['question'],
        'user_answer': answer,
        'correct_answer': quiz['answer'],
        'is_correct': is_correct
    })
    return jsonify({'is_correct': is_correct, 'correct_answer': quiz['answer']})

@app.route('/review')
def review():
    return render_template('review.html', answers=session.get('answers', []))

if __name__ == '__main__':
    app.run(debug=True)
