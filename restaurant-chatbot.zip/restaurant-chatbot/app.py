from flask import Flask, render_template, request

app = Flask(__name__)

# Simple responses for the chatbot
responses = {
    'hours': "We are open from 9 AM to 9 PM every day.",
    'location': "We are located at 123 Restaurant Street, Food City.",
    'menu': "Our menu includes Pizza, Pasta, Burgers, and Salads.",
    'reservation': "You can make a reservation by calling us at 123-456-7890.",
    'default': "I'm sorry, I didn't understand that. Can you please ask about our hours, location, menu, or reservations?"
}

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.form['user_input'].lower()
    # Return response based on user input
    response = responses.get(user_input, responses['default'])
    return render_template('index.html', user_input=user_input, response=response)

if __name__ == '__main__':
    app.run(debug=True)
